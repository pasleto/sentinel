const api_root_message = {
  application: 'Sentinel',
  description: 'Sentinel',
  author: {
    name: 'Tomáš Pásler',
    nickname: 'pasleto',
    web: 'https:/pasleto.eu/'
  },
  // api_routes: _api_routes
};

export {
  api_root_message
};