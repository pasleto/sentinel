const printData = [
  {
    'scope': 'print',
    'name': 'host_url',
    'friendly_name': 'Print Server Name',
    'description': 'Host URL (default: empty)',
    'value': '',
    'protected': false
  }
];

export default printData;
